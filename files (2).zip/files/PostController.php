<?php
namespace App\Http\Controllers;
 
 
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Post;
use Auth;
class PostController extends Controller
{
 
 
    public function index(Request $request)
    {
        $user_id= Auth::id();
        $post = Post::where('created_by', $user_id)->orderBy('id','title')->paginate(5);
        return view('post.index',compact('post'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
    }
 
    public function create()
    {
    
    return view('post.create');
    }
 
 
    public function store(Request $request)
    {
      $this->validate($request, [
            'title' => 'required',
            'subject' => 'required',
            'description' => 'required',
            /*'created_by'  =>  'required',*/
            'image' => 'image|max:2048',
        ]);

        $requestData = $request->all();

       if($request->hasFile('image')){
            $image = $request->file('image');         
        $fileName = $image->getClientOriginalName();
        // $fileExtension = $image->getClientOriginalExtension();
        $imageName = time().'.'.$request->file('image')->getClientOriginalExtension();
        $request->file('image')->move(
        base_path() . '/public/images/', $fileName);
        $requestData['image'] = $fileName;
        }
       $requestData['created_by'] = Auth::id();
        Post::create($requestData);
        return redirect()->route('posts.index')
        ->with('success','Record created successfully');

    }
 
    public function show($id)
    {
        $Post = Post::find($id);
        return view('post.show',compact('Post'));
    }
 
    public function edit($id)
    {
        $Post = Post::find($id);
        return view('post.edit',compact('Post'));
    }
 
    public function update(Request $request, $id)
    {
        
       $this->validate($request, [
            'title' => 'required',
            'subject' => 'required',
            'description' => 'required',
            'image' => 'image|max:2048',
        ]);

        $requestData = $request->all();

       if($request->hasFile('image')){
            $image = $request->file('image');         
        $fileName = $image->getClientOriginalName();
        // $fileExtension = $image->getClientOriginalExtension();
        $imageName = time().'.'.$request->file('image')->getClientOriginalExtension();
        $request->file('image')->move(
        base_path().'/public/images/', $imageName);
        }else{
             $imageName= $request->previousImg;
        }
         $updateData =array();
         $updateData['title']       = $request->title;
         $updateData['subject']     =  $request->subject;
         $updateData['description'] = $request->description;
         $updateData['image']   = $imageName;
          
    
        Post::whereId($id)->update($updateData);

        //Post::find($id)->update($from_data);
        return redirect()->route('posts.index')
                        ->with('success','Record updated successfully');
                      /*   
        return redirect('crud')->with('success', 'Data is successfully updated');
*/
      }
  

    public function destroy($id)
    {
        Post::find($id)->delete();
        return redirect()->route('posts.index')
                        ->with('success','Record deleted successfully');
    }
}
?>