
@extends('layouts.app') 
@section('content')

    <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Products</div>

                
    <div class="panel-body">
        <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

      <!--  @if(count($errors) > 0)
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif -->
    {!! Form::model($Product, ['method' => 'PATCH','route' => ['products.update', $Product->id],'files'=>true]) !!}
    
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Title:</strong>
                {!! Form::text('title', null, array('placeholder' => 'title','class' => 'form-control')) !!}
                <span class="text text-danger">{{ $errors->first('title')}}</span>
            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Subject:</strong>
                {!! Form::text('subject', null, array('placeholder' => 'subject','class' => 'form-control')) !!}
                <span class="text text-danger">{{ $errors->first('subject')}}</span>
            </div>
        </div>


        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Description:</strong>
                 {!! Form::textarea('description', null, array('placeholder' => 'Description','class' => 'form-control','style'=>'height:100px')) !!} 
                  <span class="text text-danger">{{ $errors->first('description')}}</span>               
            </div>
        </div>
         <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Product Price:</strong>
                {!! Form::text('price', null, array('placeholder' =>'Product Price','class' => 'form-control')) !!}
                 <span class="text text-danger">{{ $errors->first('price')}}</span>
            </div>
          </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Image:</strong>
                 {!! Form::hidden('previousImg', $Product->image, array('class' => 'form-control')) !!}
               {!! Form::file('image',array('placeholder' => 'Image','class' => 'form-control','onchange' => 'document.getElementById("blah").src = window.URL.createObjectURL(this.files[0])')) !!}
                <span class="text text-danger">{{ $errors->first('image')}}</span>
            </div>
            <img id="blah" src="{{URL::to('/')}}/images/{{$Product->image}}" alt="your image" width="150"/>
        </div>
         <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Is Active:</strong>
                {!! Form::checkbox('is_active',($Product->is_active==1) ? true : null, array('class' => 'form-control')) !!}
                 
            </div>
     </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
                <a class="btn btn-primary" href="{{ route('products.index') }}"> Back</a>
        </div>
    </div>
    </form>
    {!! Form::close() !!}


                </div>
            </div>
        </div>
    </div>
</div>
@endsection


   