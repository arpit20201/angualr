@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
        
                <div class="panel-heading">Products</div>

                <div class="panel-body">

              <!--   @if (count($errors) > 0)
                <div class="alert alert-danger">
                    <strong>Whoops!</strong> There were some problems with your input.<br><br>
                    <ul>
                        @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
                @endif -->
            {!! Form::open(array('route' => 'products.store','files'=>true,'method'=>'POST')) !!}
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <strong>Title:</strong>
                            {!! Form::text('title', null, array('placeholder' => 'title','class' => 'form-control')) !!}
                             <span class="text text-danger">{{ $errors->first('title')}}</span>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <strong>Description:</strong>
                            {!! Form::textarea('description', null, array('placeholder' => 'Description','class' => 'form-control','style'=>'height:100px')) !!} 
                             <span class="text text-danger">{{ $errors->first('description')}}</span>               
                        </div>
                    </div>
                      <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <strong>Product Price:</strong>
                            {!! Form::text('price', null, array('placeholder' =>'Product Price','class' => 'form-control')) !!}
                             <span class="text text-danger">{{ $errors->first('price')}}</span>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <strong>Image:</strong>
                            {!! Form::file('image',array('placeholder' => 'Image','class' => 'form-control','onchange' => 'document.getElementById("blah").src = window.URL.createObjectURL(this.files[0])')) !!}
                             <span class="text text-danger">{{ $errors->first('image')}}</span>
                        </div>
                        <img id="blah" src="#" alt="your image" width="150"/><br>
                    </div>
                     <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <strong>Is Active:</strong>
                            {!! Form::checkbox('is_active', null, array('class' => 'form-control')) !!}
                             
                        </div>
                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <a class="btn btn-primary" href="{{ route('products.index') }}">Cnacel</a>
                    </div>
                </div>
                {!! Form::close() !!}
                @endsection