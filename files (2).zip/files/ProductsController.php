<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Product;
use Auth;


class ProductsController extends Controller
{
    public function index(Request $request)
    {  
        $user_id= Auth::id();
        $product = Product::where('created_by', $user_id)->orderBy('id','title')->paginate(5);
        return view('product.index',compact('product'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
    }
 
    public function create()
    {
       
       return view('product.create');
    }

    public function store(Request $request)
    {
    	$this->validate($request, [
    		'title' => 'required',
    		'description' => 'required',
    		'price'=>'required|numeric',
    		'image' => 'image|max:2048'
        ]);

        //$requestData = $request->all();
       if($request->hasFile('image')){
            $image = $request->file('image');         
        $fileName = $image->getClientOriginalName();
        // $fileExtension = $image->getClientOriginalExtension();
        $imageName = time().'.'.$request->file('image')->getClientOriginalExtension();
        $request->file('image')->move(
        base_path() . '/public/images/', $fileName);
        $imageName = $fileName;
        }
         $requestData =array();
         $requestData['title']= $request->title;
         $requestData['description'] = $request->description;
         $requestData['price']=$request->price;
         $requestData['image'] = $imageName;
         $requestData['is_active'] =isset($request->is_active) ? 1 :0;

         $requestData['created_by'] = Auth::id();
        Product::create($requestData);
        return redirect()->route('products.index')
        ->with('success','Record created successfully');

    }
 
    public function show($id)
    {
        $Product = Product::find($id);
        return view('product.show',compact('Product'));
    }
 
    public function edit($id)
    {
        $Product = Product::find($id);
        return view('product.edit',compact('Product'));
    }
 
    public function update(Request $request, $id)
    {
        
       $this->validate($request, [
            'title' => 'required',
    		'description' => 'required',
    		'price'=>'required|numeric',
    		'image' => 'image|max:2048'
        ]);

       // $requestData = $request->all();
       if($request->hasFile('image')){
            $image = $request->file('image');         
        $fileName = $image->getClientOriginalName();
        // $fileExtension = $image->getClientOriginalExtension();
        $imageName = time().'.'.$request->file('image')->getClientOriginalExtension();
        $request->file('image')->move(
        base_path().'/public/images/', $imageName);
        }else{
             $imageName= $request->previousImg;
        }
         $updateData =array();
         $updateData['title']= $request->title;
         $updateData['description'] = $request->description;
         $updateData['price']=$request->price;
         $updateData['image'] = $imageName;
         $updateData['is_active'] =isset($request->is_active) ? 1 :0;
        Product::whereId($id)->update($updateData);
        return redirect()->route('products.index')
                        ->with('success','Record updated successfully');
                      
      }
    public function destroy($id)
    {
        Product::find($id)->delete();
        return redirect()->route('products.index')
                        ->with('success','Record deleted successfully');
    }

}
  